/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frete;

/**
 *
 * @author eduar
 */
public class Contexto {
    private IFrete freteStrategy = null;
    
    public double CalculaFrete(){
        return freteStrategy.Calcular();
    }
    
    public IFrete getFreteStrategy(){
        return this.freteStrategy;
    }
    
    public void setFreteStrategy(IFrete freteStrategy){
        this.freteStrategy = freteStrategy;
    }
}
