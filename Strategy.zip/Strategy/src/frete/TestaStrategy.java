/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frete;

import java.util.Scanner;

/**
 *
 * @author eduar
 */
public class TestaStrategy {
    public static void main(String[] args){
        exemploStrategy();
    }
    
    public static void exemploStrategy(){
        Scanner leitor = new Scanner(System.in);
        
        Contexto frete = new Contexto();
        
        System.out.print("Digite a distância(km): ");
        double distancia = leitor.nextDouble();
        
        System.out.print("Digite S para Sedex ou N para Normal(S/N): ");
        String resposta = leitor.next();
        
        if("s".equalsIgnoreCase(resposta)){
            frete.setFreteStrategy(new Sedex(distancia));
        }
        else{
            frete.setFreteStrategy(new Normal(distancia));
        }
        
        System.out.println("Valor do frete: " + frete.CalculaFrete());
    }
}
