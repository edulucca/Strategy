/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frete;

/**
 *
 * @author eduar
 */
public class Sedex implements IFrete{
    
    private double distancia;

    public Sedex(double distancia) {
        this.distancia = distancia;
    }

    @Override
    public double Calcular() {
        double valor = 0;
        
        valor = this.distancia * 2.75;
        
        return valor;
    }
    
}
