
package frete;

/**
 *
 * @author eduar
 */
public interface IFrete {
    abstract double Calcular();
}
